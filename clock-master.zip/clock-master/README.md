# Simple clock ESP8266
It just play sound as arlarm.
Frequence update GMT time.
